<?php
    // Conectar a la base de datos SQLite
    $db = new SQLite3('D:/XAMPP/htdocs/dashboard/sqlite/librarycb133.db');

    // Obtener el valor del id desde la URL
    $id = $_GET['id'];

    // Consultar los datos de la fila que coincide con el id
    $stmt = $db->prepare('SELECT * FROM books WHERE Id = :id');
    $stmt->bindValue(':id', $id, SQLITE3_TEXT);

    $results = $stmt->execute();

    // Mostrar los datos
    while ($row = $results->fetchArray()) {
        echo "<ul>";
        foreach ($row as $col => $value) {
            echo "<li>" . htmlspecialchars($col) . ": " . htmlspecialchars($value) . "</li>";
        }
        echo "</ul>";
    }
?>

